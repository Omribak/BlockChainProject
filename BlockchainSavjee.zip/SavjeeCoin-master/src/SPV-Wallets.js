const EC = require('elliptic').ec;
const ec = new EC('secp256k1');

const keySPV1 = ec.genKeyPair();
const SPVpublicKey1 = keySPV1.getPublic('hex');
const SPVprivateKey1 = keySPV1.getPrivate('hex');

console.log(SPVpublicKey1);
console.log(SPVprivateKey1);

const keySPV2 = ec.genKeyPair();
const SPVpublicKey2 = keySPV2.getPublic('hex');
const SPVprivateKey2 = keySPV2.getPrivate('hex');

console.log(SPVpublicKey2);
console.log(SPVprivateKey2);
