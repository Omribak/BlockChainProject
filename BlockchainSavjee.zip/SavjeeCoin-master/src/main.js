'use strict';
const { PartitionedBloomFilter } = require('bloom-filters');
const filter = new PartitionedBloomFilter(10, 5);
const { Blockchain, Transaction } = require('./blockchain');
const EC = require('elliptic').ec;
const ec = new EC('secp256k1');
const { MerkleTree } = require('merkletreejs');

const SHA256 = require('crypto-js/sha256');

// Your private key goes here
const myKey = ec.keyFromPrivate(
  '7c4c45907dec40c91bab3480c39032e90049f1a44f3e18c3e07c23e3273995cf'
);

const SPVKey1 = ec.keyFromPrivate(
  'eedd9dca0791fb6fc424e485c758394845270fc1a4e6fdd990e674787a8ead8d'
);
const SPVKey2 = ec.keyFromPrivate(
  'ff98512305914afa40344e53a7433a5b99f4587c8439393fc3083b4c8061be38'
);

// From that we can calculate your public key (which doubles as your wallet address)
const myWalletAddress = myKey.getPublic('hex');

const SPVWalletAddress1 = SPVKey1.getPublic('hex');
const SPVWalletAddress2 = SPVKey2.getPublic('hex');

console.log(SPVWalletAddress1);
console.log(SPVWalletAddress2);

// Create new instance of Blockchain class
const savjeeCoin = new Blockchain();

// Mine first block
savjeeCoin.minePendingTransactions(myWalletAddress);
savjeeCoin.minePendingTransactions(myWalletAddress);
savjeeCoin.minePendingTransactions(myWalletAddress);
savjeeCoin.minePendingTransactions(myWalletAddress);
savjeeCoin.minePendingTransactions(myWalletAddress);

savjeeCoin.minePendingTransactions(SPVWalletAddress1);
savjeeCoin.minePendingTransactions(SPVWalletAddress1);
savjeeCoin.minePendingTransactions(SPVWalletAddress1);
savjeeCoin.minePendingTransactions(SPVWalletAddress1);
savjeeCoin.minePendingTransactions(SPVWalletAddress1);

savjeeCoin.minePendingTransactions(SPVWalletAddress2);
savjeeCoin.minePendingTransactions(SPVWalletAddress2);
savjeeCoin.minePendingTransactions(SPVWalletAddress2);
savjeeCoin.minePendingTransactions(SPVWalletAddress2);
savjeeCoin.minePendingTransactions(SPVWalletAddress2);

console.log(
  `Balance of xavier is ${savjeeCoin.getBalanceOfAddress(myWalletAddress)}`
);

console.log(
  `Balance of SPVWallet1 is ${savjeeCoin.getBalanceOfAddress(
    SPVWalletAddress1
  )}`
);

console.log(
  `Balance of SPVWallet2 is ${savjeeCoin.getBalanceOfAddress(
    SPVWalletAddress2
  )}`
);

// Create a transaction & sign it with your key
const tx1 = new Transaction(myWalletAddress, 'address2', 10);
tx1.sign(myKey);
savjeeCoin.addTransaction(tx1);
const tx2 = new Transaction(myWalletAddress, 'address2', 10);
tx2.sign(myKey);
savjeeCoin.addTransaction(tx2);
const tx3 = new Transaction(myWalletAddress, 'address2', 10);
tx3.sign(myKey);
savjeeCoin.addTransaction(tx3);

const leaves = [tx1, tx2, tx3].map((x) => SHA256(x));
const tree = new MerkleTree(leaves, SHA256);
const root = tree.getRoot();
const proof = tree.getProof(leaves[0]);
const verified = tree.verify(proof, leaves[0], root);
console.log('Leaf is verified ?', verified);

filter.add(tx1);
console.log('filter has transaction?', filter.has(tx1));

// Mine block
savjeeCoin.minePendingTransactions(myWalletAddress);

console.log(savjeeCoin.chain);
// console.log(tx1);

// // Create second transaction
// const tx2 = new Transaction(myWalletAddress, 'address1', 30);
// tx2.sign(myKey);
// savjeeCoin.addTransaction(tx2);

// // Mine block
// savjeeCoin.minePendingTransactions(myWalletAddress);

// console.log();
// console.log(
//   `Balance of xavier is ${savjeeCoin.getBalanceOfAddress(myWalletAddress)}`
// );

// Uncomment this line if you want to test tampering with the chain
// savjeeCoin.chain[1].transactions[0].amount = 10;

// Check if the chain is valid

const txs1 = savjeeCoin.getAllTransactionsForWallet(myWalletAddress);
let result = 0;
for (let i = 0; i < txs1.length; i++) {
  result = result + txs1[i].amount;
}
const txs2 = savjeeCoin.getAllTransactionsForWallet(SPVWalletAddress1);
for (let i = 0; i < txs2.length; i++) {
  result = result + txs2[i].amount;
}
const txs3 = savjeeCoin.getAllTransactionsForWallet(SPVWalletAddress2);
for (let i = 0; i < txs3.length; i++) {
  result = result + txs3[i].amount;
}
console.log('All network amount of money:', result);
console.log();
console.log('Blockchain valid?', savjeeCoin.isChainValid() ? 'Yes' : 'No');
